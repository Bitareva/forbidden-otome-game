
import { useState } from 'react';

export default function ForbiddenOtomeGame() {
  const [scene, setScene] = useState(0);
  const [choiceHistory, setChoiceHistory] = useState([]);

  const nextScene = (choice) => {
    setChoiceHistory([...choiceHistory, choice]);
    setScene(scene + 1);
  };

  const scenes = [
    {
      text: `Kamar sunyi. William duduk deket lo, matanya fokus. Dia bilang, “Lo ngarep gue yang mulai duluan ya?”
      Nafasnya deket banget. Tangan dia udah nyentuh pundak lo pelan.`,
      choices: [
        { label: "Gue penasaran lo bakal ngapain", value: "A" },
        { label: "Jangan bikin gue nyesel ya", value: "B" },
        { label: "Mau buktiin sekarang?", value: "C" },
      ],
    },
    {
      text: `William narik lo makin deket. Dia bisik di telinga lo, "Gue buktiin ya... pelan-pelan dulu. Biar lo nagih."
      Tangan dia turun dari bahu ke pinggang. Deg-degan lo makin kenceng.`,
      choices: [
        { label: "Cium balik, ambil alih kontrol", value: "A" },
        { label: "Tapi jangan terlalu cepet ya", value: "B" },
        { label: "Mainnya pelan-pelan aja, Will", value: "C" },
      ],
    },
    {
      text: `Tiba-tiba ada suara ketukan pintu. Oliver nyari lo. William bisik, “Lo bahaya. Kalo gue jatuh beneran, lo siap tanggung jawab?”
      Tapi lo belum sempet jawab...`,
      choices: [
        { label: "Sembunyi di balik William", value: "A" },
        { label: "Keluar dan temui Oliver", value: "B" },
        { label: "Bisik ke William: nanti kita lanjutin", value: "C" },
      ],
    },
  ];

  if (scene >= scenes.length) {
    return (
      <div className="text-center p-6">
        <p>🔥 Cerita kamu selesai sampai di sini! 🔥</p>
        <p>Riwayat pilihan kamu: {choiceHistory.join(', ')}</p>
        <button className="mt-4 bg-pink-500 px-4 py-2 rounded" onClick={() => { setScene(0); setChoiceHistory([]); }}>Main Ulang</button>
      </div>
    );
  }

  const current = scenes[scene];

  return (
    <div className="space-y-4 p-4 bg-gray-900 rounded-lg shadow-lg">
      <p>{current.text}</p>
      <div className="flex flex-col space-y-2">
        {current.choices.map((c, index) => (
          <button key={index} className="bg-pink-600 hover:bg-pink-700 px-4 py-2 rounded" onClick={() => nextScene(c.value)}>{c.label}</button>
        ))}
      </div>
    </div>
  );
}
